#pragma once
#include "CScene.h"
class CScene_Start:
	public CScene
{
};

