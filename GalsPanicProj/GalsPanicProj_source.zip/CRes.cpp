#include "pch.h"
#include "CRes.h"
