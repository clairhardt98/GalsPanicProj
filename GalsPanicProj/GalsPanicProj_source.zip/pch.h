#pragma once

#include <Windows.h>
#include <iostream>
#include <vector>
#include <string>
#include <cassert>

#include "define.h"
#include "Vector2D.h"

#pragma comment(lib,"Msimg32.lib")